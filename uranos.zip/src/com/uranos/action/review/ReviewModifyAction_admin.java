package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;
import com.uranos.model.ReviewVO;

public class ReviewModifyAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();
		boolean result = false;
		int num = Integer.parseInt(request.getParameter("REVIEW_NUM"));
		int nowpage = Integer.parseInt(request.getParameter("REVIEW_PAGE"));
		int search = Integer.parseInt(request.getParameter("REVIEW_SEARCH"));
		ReviewVO rvo = new ReviewVO();
		HttpSession session = request.getSession();
		String nick = (String) session.getAttribute("nick");
		/*
		 * if (usercheck == false) {
		 * response.setContentType("text/html;charset=UTF-8"); PrintWriter out =
		 * response.getWriter(); out.println("<script>");
		 * out.println("alert('수정할 권한이 없습니다.');");
		 * out.println("location.href='./BoardList.bo';");
		 * out.println("</script>"); out.close(); return null; }
		 */
		try {
			rvo.setRw_num(num);
			rvo.setRw_title(request.getParameter("REVIEW_TITLE"));
			rvo.setRw_content(request.getParameter("REVIEW_CONTENT"));
			rvo.setRw_file(request.getParameter("REVIEW_FILE"));
			result = ReviewDAO.reviewModify(rvo);
			if (result == false) {
				return null;
			}
			forward.setRedirect(true);
			System.out.println(rvo.getRw_num());
			forward.setPath("./ReviewDetailAction_admin.ura?num=" + rvo.getRw_num() + "&page=" + nowpage + "&search=" + search);
			// return forward;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return forward;
	}
}