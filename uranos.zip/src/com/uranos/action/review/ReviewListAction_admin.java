package com.uranos.action.review;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;
import com.uranos.model.ReviewVO;

public class ReviewListAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		HttpSession session = request.getSession();
		List<ReviewVO> boardlist = new ArrayList<>();

		int pageNo = 1;
		int search = 1;
		if (request.getParameter("search") != null) {
			search = Integer.parseInt(request.getParameter("search"));
		}

		if (request.getParameter("page") != null) {
			System.out.println("page = Not null");
			pageNo = Integer.parseInt(request.getParameter("page"));
		}
		if (search == 0) {
			System.out.println("page = null");
			session.removeAttribute("boarddata");
			session.removeAttribute("searchText");
			session.removeAttribute("comboBox");
		}
		List<ReviewVO> boardList = (List<ReviewVO>) session.getAttribute("boarddata");
		String searchText = (String) session.getAttribute("searchText");
		System.out.println(searchText);
		String comboBox = (String) session.getAttribute("comboBox");
		if (boardList == null) {
			System.out.println("boardList = null");
			final int ROW_PER_PAGE = 10; // 페이지당 레코드 출력 갯수
			int begin = (pageNo - 1) * ROW_PER_PAGE + 1; // 1, 11, 21, 31
			int end = pageNo * ROW_PER_PAGE; // 10, 20, 30, 40

			// 시작 페이지와 끝 페이지를 조건으로 리스트 가져오기
			int totalRows = ReviewDAO.getListCount(); // 전체 게시물 갯수
			int totalPages = (int) Math.ceil((double) totalRows / ROW_PER_PAGE);
			// 전체 페이지 갯수
			boardlist = ReviewDAO.getBoardList(begin, end);

			final int PAGE_PER_PAGE = 10; // 화면당 페이지 출력 갯수
			int totalRanges = (int) Math.ceil((double) totalPages / PAGE_PER_PAGE); // 전체
																					// Range
																					// 갯수
			int currentRange = (int) Math.ceil((double) pageNo / PAGE_PER_PAGE);
			// 요청된 pageNo의 현재 range
			int beginPage = (currentRange - 1) * PAGE_PER_PAGE + 1; // 시작 페이지 번호
																	// 1,
																	// 11, 21,
																	// 31
			int endPage = currentRange * PAGE_PER_PAGE; // 마지막 페이지 번호 10, 20,
														// 30, 40
			if (currentRange == totalRanges)
				endPage = totalPages; // currentRange가 맨 마지막 range인 경우

			int prevPage = 0;
			if (currentRange != 1)
				prevPage = (currentRange - 2) * PAGE_PER_PAGE + 1;
			int nextPage = 0;
			if (currentRange != totalRanges)
				nextPage = currentRange * PAGE_PER_PAGE + 1;

			request.setAttribute("page", pageNo);
			request.setAttribute("listcount", totalRows);
			request.setAttribute("beginpage", beginPage);
			request.setAttribute("endpage", endPage);
			request.setAttribute("prevpage", prevPage);
			request.setAttribute("nextpage", nextPage);
			request.setAttribute("totalpages", totalPages);
			request.setAttribute("search", search);
			session.setAttribute("boardlist", boardlist);

		} else {
			System.out.println("boardList = not null");
			boardlist = boardList;
			// boardlist = ReviewDAO.getBoardList(begin, end);

			final int ROW_PER_PAGE = 10; // 페이지당 레코드 출력 갯수
			int begin = (pageNo - 1) * ROW_PER_PAGE + 1; // 1, 11, 21, 31
			int end = pageNo * ROW_PER_PAGE; // 10, 20, 30, 40

			// 시작 페이지와 끝 페이지를 조건으로 리스트 가져오기
			int totalRows = ReviewDAO.getListSearchCount(searchText); // 전체 게시물
																		// 갯수
			int totalPages = (int) Math.ceil((double) totalRows / ROW_PER_PAGE);
			// 전체 페이지 갯수

			if (comboBox.equals("제목")) {
				boardlist = ReviewDAO.searchTitle(searchText, begin, end);
			} else if (comboBox.equals("내용")) {
				boardlist = ReviewDAO.searchContent(searchText, begin, end);
			} else if (comboBox.equals("제목+내용")) {
				boardlist = ReviewDAO.searchTitleContent(searchText, begin, end);
			} else if (comboBox.equals("작성자")) {
				boardlist = ReviewDAO.searchNick(searchText, begin, end);
			}

			final int PAGE_PER_PAGE = 10; // 화면당 페이지 출력 갯수
			int totalRanges = (int) Math.ceil((double) totalPages / PAGE_PER_PAGE); // 전체
																					// Range
																					// 갯수
			int currentRange = (int) Math.ceil((double) pageNo / PAGE_PER_PAGE);
			// 요청된 pageNo의 현재 range
			int beginPage = (currentRange - 1) * PAGE_PER_PAGE + 1; // 시작 페이지 번호
																	// 1,
																	// 11, 21,
																	// 31
			int endPage = currentRange * PAGE_PER_PAGE; // 마지막 페이지 번호 10, 20,
														// 30, 40
			if (currentRange == totalRanges)
				endPage = totalPages; // currentRange가 맨 마지막 range인 경우

			int prevPage = 0;
			if (currentRange != 1)
				prevPage = (currentRange - 2) * PAGE_PER_PAGE + 1;
			int nextPage = 0;
			if (currentRange != totalRanges)
				nextPage = currentRange * PAGE_PER_PAGE + 1;

			request.setAttribute("page", pageNo);
			request.setAttribute("listcount", totalRows);
			request.setAttribute("beginpage", beginPage);
			request.setAttribute("endpage", endPage);
			request.setAttribute("prevpage", prevPage);
			request.setAttribute("nextpage", nextPage);
			request.setAttribute("totalpages", totalPages);
			request.setAttribute("search", search);
			session.setAttribute("boardlist", boardlist);
		}

		forward.setRedirect(false);
		forward.setPath("./review/review_admin.jsp");
		return forward;
	}
}
