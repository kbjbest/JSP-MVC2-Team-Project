package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;
import com.uranos.model.ReviewVO;

public class ReviewModifyView implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("ReveeiwModifyView 들어옴");
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		ReviewVO rvo = new ReviewVO();

		int num = Integer.parseInt(request.getParameter("num"));
		//int nowpage = Integer.parseInt(request.getParameter("page"));
		rvo = ReviewDAO.getDetail(num);

		if (rvo == null) {
			return null;
		}

		request.setAttribute("boarddata", rvo);
		forward.setRedirect(false);
		forward.setPath("./review/modify.jsp");
		System.out.println("ReveeiwModifyView 나감");
		return forward;
	}
}