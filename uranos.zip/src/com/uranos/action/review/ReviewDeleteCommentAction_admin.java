package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;

public class ReviewDeleteCommentAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");

		int cno = Integer.parseInt(request.getParameter("cno"));
		int boardNo = Integer.parseInt(request.getParameter("no"));
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		int search =  Integer.parseInt(request.getParameter("search"));
		System.out.println(boardNo + "ㅎㅎㅎ" + pageNo);
		boolean result = false;

		result = ReviewDAO.commentDelete(cno);
		if (result == false) {
			return null;
		}

		forward.setRedirect(true);
		forward.setPath("./ReviewDetailAction._admin.ura?num=" + boardNo + "&page=" + pageNo + "&search=" + search);
		return forward;
	}
}