package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;

public class ReviewDeleteAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		String search = (String) request.getParameter("search");

		boolean result = false;
		int num = Integer.parseInt(request.getParameter("num"));
		/*
		 * usercheck = boarddao.isBoardWriter(num, id);
		 * 
		 * if (usercheck == false) {
		 * response.setContentType("text/html;charset=UTF-8"); PrintWriter out =
		 * response.getWriter(); out.println("<script>");
		 * out.println("alert('삭제할 권한이 없습니다.');");
		 * out.println("location.href='./BoardList.bo';");
		 * out.println("</script>"); out.close(); return null; }
		 */
		result = ReviewDAO.boardDelete(num);
		if (result == false) {
			return null;
		}

		forward.setRedirect(true);
		forward.setPath("./ReviewList.ura?search=" + search);
		return forward;
	}
}