package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;
import com.uranos.model.ReviewVO;

public class ReviewDetailAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		System.out.println("후기 상세보기 액션");

		ReviewVO rvo = new ReviewVO();

		int nowpage = Integer.parseInt(request.getParameter("page"));
		int num = Integer.parseInt(request.getParameter("num"));
		ReviewDAO.setReadCountUpdate(num);
		rvo = ReviewDAO.getDetail(num);

		if (rvo == null) {
			return null;
		}

		request.setAttribute("page", nowpage);
		request.setAttribute("num", num);
		request.setAttribute("boarddata", rvo);
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./review/detail_admin.jsp");
		
		return forward;
	}
}