package com.uranos.action.review;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.CommentVO;
import com.uranos.model.ReviewDAO;

public class ReviewAddCommentAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		PrintWriter writer = response.getWriter();
		request.setCharacterEncoding("UTF-8");

		request.setCharacterEncoding("utf-8");

		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		String search = request.getParameter("search");
		String content = request.getParameter("content");
		System.out.println(request.getParameter("m_num"));

		if (request.getParameter("m_num") != null) {
			System.out.println("ㅋ?");
			int m_num = Integer.parseInt(request.getParameter("m_num"));

			boolean addcomment = false;
			System.out.println(boardNo + " " + m_num + " " + content);

			CommentVO comment = new CommentVO();
			comment.setRw_num(boardNo);
			comment.setM_num(m_num);
			comment.setCo_content(content);
			addcomment = ReviewDAO.addComment(comment);

			if (addcomment == false) {
				return null;
			}
		} else {
			writer.println("<script type='text/javascript'>");
			writer.println("alert('로그인을 하십시오.');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();

		}

		forward.setRedirect(true);
		forward.setPath("./ReviewDetailAction.ura?num=" + boardNo + "&page=" + pageNo + "&search=" + search);
		return forward;
	}
}