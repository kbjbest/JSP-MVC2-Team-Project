package com.uranos.action.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewDAO;
import com.uranos.model.ReviewVO;

public class ReviewAddAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ReviewVO rvo = new ReviewVO();
		ActionForward forward = new ActionForward();

		String savePath = request.getServletContext().getRealPath("/upload");
		System.out.println(savePath);
		int fileSize = 5 * 1024 * 1024;

		boolean result = false;

		try {

			MultipartRequest multi = new MultipartRequest(request, savePath, fileSize, "utf-8",
					new DefaultFileRenamePolicy());
			String rw_title = multi.getParameter("RW_TITLE");
			String rw_content = multi.getParameter("RW_CONTENT");
			String fileName = multi.getFilesystemName("RW_FILE");
			int rw_m_num = Integer.parseInt(multi.getParameter("RW_M_NUM"));
			String m_fileFullPath = savePath + "/" + fileName;

			rvo.setRw_title(rw_title);
			rvo.setRw_content(rw_content);
			rvo.setRw_file(fileName);
			rvo.setM_num(rw_m_num);

			result = ReviewDAO.reviewInsert(rvo);
			request.setAttribute("rvo", rvo);

			if (result == false) {
				return null;
			}

			forward.setRedirect(true);
			forward.setPath("ReviewList.ura?search=0");
			return forward;

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}