package com.uranos.action.review;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ReviewVO;

public class ReviewSearchAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		List<ReviewVO> boardlist = new ArrayList<>();
		HttpSession session = request.getSession();
		session.removeAttribute("boarddata");
		session.removeAttribute("searchText");
		session.removeAttribute("combobox");
		System.out.println("검색1");
		ReviewVO rvo = new ReviewVO();
		ActionForward forward = new ActionForward();
		String searchText = request.getParameter("getTxt");
		String combobox = request.getParameter("hiddenSearch");
		System.out.println(combobox);

		session.setAttribute("boarddata", boardlist);
		session.setAttribute("searchText", searchText);
		session.setAttribute("comboBox", combobox);
	

		//request = (HttpServletRequest)param; //req로 받으면 됩니다. 

		
		//HashMap<String, Integer> map = new HashMap<String, Integer>();
		//map.put("page", 1);

		forward.setRedirect(false);
		forward.setPath("./ReviewList._admin.ura?page=1&search=1");

		return forward;
	}
}