package com.uranos.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.member.MemberAdjustAction;
import com.uranos.action.member.MemberListAction;
import com.uranos.action.member.MemberLoginAction;
import com.uranos.action.member.MemberLogoutAction;
import com.uranos.action.member.MemberSignupAction;
import com.uranos.action.notice.NoticeAddAction;
import com.uranos.action.notice.NoticeDeleteAction;
import com.uranos.action.notice.NoticeDetailAction;
import com.uranos.action.notice.NoticeListAction;
import com.uranos.action.notice.NoticeModifyAction;
import com.uranos.action.notice.NoticeModifyView;
import com.uranos.action.notice.ServiceDetailAction;
import com.uranos.action.notice.ServiceListAction;
import com.uranos.action.qna.QnaAddAction;
import com.uranos.action.qna.QnaAddAction_admin;
import com.uranos.action.qna.QnaDeleteAction;
import com.uranos.action.qna.QnaDeleteAction_admin;
import com.uranos.action.qna.QnaDetailAction;
import com.uranos.action.qna.QnaDetailAction_admin;
import com.uranos.action.qna.QnaListAction;
import com.uranos.action.qna.QnaList_adminAction;
import com.uranos.action.qna.QnaModifyAction;
import com.uranos.action.qna.QnaModifyAction_admin;
import com.uranos.action.qna.QnaModifyView;
import com.uranos.action.qna.QnaModifyView_admin;
import com.uranos.action.qna.QnaReplyAction;
import com.uranos.action.qna.QnaReplyAction_admin;
import com.uranos.action.qna.QnaReplyView;
import com.uranos.action.qna.QnaReplyView_admin;
import com.uranos.action.reserve.ResAdminDeleteAction;
import com.uranos.action.reserve.ResAdminDetailAction;
import com.uranos.action.reserve.ResAdminInsertAction;
import com.uranos.action.reserve.ResAdminRserveListAction;
import com.uranos.action.reserve.ResAdminUpdateAction;
import com.uranos.action.reserve.ResDeleteActon;
import com.uranos.action.reserve.ResDetailAction;
import com.uranos.action.reserve.ResFormAction;
import com.uranos.action.reserve.ResInsertAction;
import com.uranos.action.reserve.ResUserCheckListAction;
import com.uranos.action.reserve.ResUserUpdateAction;
import com.uranos.action.review.ReviewAddAction;
import com.uranos.action.review.ReviewAddAction_admin;
import com.uranos.action.review.ReviewAddCommentAction;
import com.uranos.action.review.ReviewAddCommentAction_admin;
import com.uranos.action.review.ReviewDeleteAction;
import com.uranos.action.review.ReviewDeleteAction_admin;
import com.uranos.action.review.ReviewDeleteCommentAction;
import com.uranos.action.review.ReviewDeleteCommentAction_admin;
import com.uranos.action.review.ReviewDetailAction;
import com.uranos.action.review.ReviewDetailAction_admin;
import com.uranos.action.review.ReviewListAction;
import com.uranos.action.review.ReviewListAction_admin;
import com.uranos.action.review.ReviewModifyAction;
import com.uranos.action.review.ReviewModifyAction_admin;
import com.uranos.action.review.ReviewModifyView;
import com.uranos.action.review.ReviewModifyView_admin;
import com.uranos.action.review.ReviewSearchAction;
import com.uranos.action.review.ReviewSearchAction_admin;

public class UranosFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UranosFrontController() {
        super();
    }

    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String RequestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = RequestURI.substring(contextPath.length());
		ActionForward forward = null;
		Action action = null;
		
		System.out.println(command);
		
		switch (command) {
		
			/** TODO 멤버 : 안희태 */
			/** 사용자 인덱스 */
		case "/index.ura": // 사용자 인덱스 페이지
			forward = new ActionForward();
			
			// 관리자가 사용자 인덱스 페이지로 넘어오면 자동으로 관리자 인덱스 페이지로 이동.
			if (request.getSession().getAttribute("grade") != null && (Integer)request.getSession().getAttribute("grade") == 0) {
				forward.setRedirect(true);
				forward.setPath("index_admin.ura");
				
			} else { // 아니면 사용자 인덱스 페이지로 이동.
				forward.setRedirect(false);
				forward.setPath("index.jsp");
			}
			
			break;

			/** 관리자 인덱스 */
		case "/index_admin.ura": // 관리자 인덱스 페이지
			forward = new ActionForward();
			forward.setRedirect(false);
			
			// 로그인이 되지 않거나, 관리자가 아닐 때 관리자 로그인 페이지로 이동.
			if (!(request.getSession().getAttribute("id") != null && request.getSession().getAttribute("id").equals("admin"))) {
				forward.setPath("login_admin.ura");
			} else {
				forward.setPath("res_adminReserveList.ura");				
			}
//			forward.setPath("index_admin.jsp");
			break;
			
			
			/** 로그인 페이지 */
		case "/login.ura": // 사용자 로그인 페이지
			forward = new ActionForward();
			
			// 로그인이 되어 있다면
			if (request.getSession().getAttribute("id") != null) {
				int grade = (Integer) request.getSession().getAttribute("grade");
				switch (grade) {
				case 0: // 등급이 관리자일 때 관리자 인덱스 페이지로 이동.
					forward.setRedirect(true);
					forward.setPath("index_admin.ura");
					break;

				case 1: // 등급이 사용자일 때 사용자 인덱스 페이지로 이동.
					forward.setRedirect(true);
					forward.setPath("index.ura");
					break;
				}
			} else { // 로그인이 되어 있지 않다면 사용자 로그인 페이지로 이동.
				forward.setRedirect(false);
				forward.setPath("./member/login.jsp");
			}
			break;
			
			/** 관리자 로그인 페이지 */
		case "/login_admin.ura": // 관리자 로그인 페이지
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./member/login_admin.jsp");
			break;
			
			/** 로그인 액션 */
		case "/loginAction.ura": // 로그인 액션
			action = new MemberLoginAction();
			try {
				if (request.getSession().getAttribute("id") != null) { // 로그인이 되어 있다면
					forward = new ActionForward();
					forward.setRedirect(true);
					forward.setPath("index.ura"); // 사용자 인덱스 페이지로 이동
					
				} else { // 로그인이 되어 있지 않다면 로그인 처리
					forward = action.execute(request, response);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 로그아웃 액션 */
		case "/logoutAction.ura": // 로그아웃 액션
			action = new MemberLogoutAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 회원가입 페이지 */
		case "/signup.ura": // 회원가입 페이지
			forward = new ActionForward();
			
			// 로그인이 되어 있다면 해당 인덱스로 이동.
			if (request.getSession().getAttribute("id") != null) {
				int grade = (Integer) request.getSession().getAttribute("grade");
				switch (grade) {
				case 0:
					forward.setRedirect(true);
					forward.setPath("index_admin.ura");
					break;

				case 1:
					forward.setRedirect(true);
					forward.setPath("index.ura");
					break;
				}
			} else {
				forward.setRedirect(false);
				forward.setPath("./member/member_signup.jsp");
			}
			
			break;
			
			/** 회원가입 액션 */
		case "/signupAction.ura": // 회원가입 처리
			action = new MemberSignupAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 마이 페이지 */
		case "/mypage.ura": // 마이 페이지
			forward = new ActionForward();
			
			// 관리자가 마이 페이지 화면으로 넘어오면 자동으로 관리자 인덱스로 이동.
			if (request.getSession().getAttribute("grade") != null) {
				if ((Integer)request.getSession().getAttribute("grade") == 0) {
					forward.setRedirect(true);
					forward.setPath("index_admin.ura");
				} else {
					forward.setRedirect(false);
					forward.setPath("./myPage.jsp");
				}
			} else { // 로그인이 되어 있지 않다면 로그인 페이지로 이동.
				forward.setRedirect(true);
				forward.setPath("login.ura?uri=mypage.ura");
			}
			break;
			
			/** 회원 정보 수정 액션 */
		case "/adjustAction.ura": // 회원 정보 수정 액션
			action = new MemberAdjustAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 회원 관리 페이지 */
		case "/memberManagement_admin.ura": // 회원 관리 페이지
			forward = new ActionForward();
			
			// 관리자가 사용자 인덱스 페이지로 넘어오면 자동으로 관리자 인덱스 페이지로 이동.
			if (request.getSession().getAttribute("grade") != null && (Integer) request.getSession().getAttribute("grade") == 0) {
				action = new MemberListAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}

			} else { // 아니면 사용자 인덱스 페이지로 이동.
				forward.setRedirect(true);
				forward.setPath("index.ura");
			}
			break;			
			
			/** 회원 정보 상세 페이지 */
		case "/memberDetail_admin.ura":
			forward = new ActionForward();
			
			// 관리자가 사용자 인덱스 페이지로 넘어오면 자동으로 관리자 인덱스 페이지로 이동.
			if (request.getSession().getAttribute("grade") != null && (Integer) request.getSession().getAttribute("grade") == 0) {
				forward.setRedirect(false);
				forward.setPath("member/member_detail_admin.jsp");

			} else { // 아니면 사용자 인덱스 페이지로 이동.
				forward.setRedirect(true);
				forward.setPath("index.ura");
			}
			break;
			
			/** 회원 정보 수정 페이지 */
		case "/memberAdjust_admin.ura":
			forward = new ActionForward();
			
			// 관리자가 사용자 인덱스 페이지로 넘어오면 자동으로 관리자 인덱스 페이지로 이동.
			if (request.getSession().getAttribute("grade") != null && (Integer) request.getSession().getAttribute("grade") == 0) {
				forward.setRedirect(false);
				forward.setPath("member/member_adjust_admin.jsp");

			} else { // 아니면 사용자 인덱스 페이지로 이동.
				forward.setRedirect(true);
				forward.setPath("index.ura");
			}
			break;
			
			/** TODO 문의 : 이재호 */
			/** TODO QnA 글쓰기 페이지 */
		case "/qnaWrite.ura": 
			forward = new ActionForward();
			
			if (request.getSession().getAttribute("grade") != null) {
				if ((Integer) request.getSession().getAttribute("grade") == 0) {
					forward.setRedirect(true);
					forward.setPath("index_admin.ura");
				} else {
					forward.setRedirect(false);
					forward.setPath("./qna/qnaWrite.jsp");	
				}
			} else { 
				forward.setRedirect(true);
				forward.setPath("login.ura?uri=qnaWrite.ura");
			}
			
			break;
			
		case "/qnaWrite_admin.ura": 
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./qna/qnaWrite_admin.jsp");
			break;
			
			/** TODO QnA 글 삭제 페이지 */
		case "/qnaDelete.ura": 
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./qna/qnaDelete.jsp");
			break;
			
			/** TODO QnA 글 수정 페이지 */
		case "/qnaModify.ura": 
			action = new QnaModifyView();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** TODO QnA 글 수정 페이지 */
			case "/qnaModify_admin.ura": 
				action = new QnaModifyView_admin();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
		
			
			/** TODO QnA 글 추가 액션 */
		case "/qnaAddAction.ura": 
			action = new QnaAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 글 추가 액션 */
			case "/qnaAddAction_admin.ura": 
				action = new QnaAddAction_admin();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;	
				
			/** TODO QnA 글 수정 액션 */
		case "/qnaModifyAction.ura":
			action = new QnaModifyAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
		
		
			/** TODO QnA 글 삭제 액션 */
		case "/qnaDeleteAction.ura":
			action = new QnaDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 글 수정 페이지 */
		case "/qnaModifyAction_admin.ura": 
			action = new QnaModifyAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** TODO QnA 글 삭제 액션 */
		case "/qnaDeleteAction_admin.ura":
			action = new QnaDeleteAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 글 목록 액션 */
		case "/qnaList.ura":
			action = new QnaListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 글 목록 액션 관리자 */
		case "/qnaList_admin.ura":
			action = new QnaList_adminAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 상세보기 액션 */
		case "/qnaDetailAction.ura":
			action = new QnaDetailAction();
			forward = new ActionForward();
			
			if (request.getSession().getAttribute("id") != null) {
				int grade = (Integer) request.getSession().getAttribute("grade");
				switch (grade) {
				case 0: // 등급이 관리자일 때 관리자 인덱스 페이지로 이동.
					forward.setRedirect(true);
					forward.setPath("index_admin.ura");
					break;

				case 1: // 등급이 사용자일 때 사용자 인덱스 페이지로 이동.
					try {
						forward = action.execute(request, response);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else { 
				forward.setRedirect(false);
				forward.setPath("login.ura?uri=qnaDetailAction.ura&num=" + request.getParameter("num"));
			}			
			break;	
			
			/** TODO QnA 상세보기 액션 */
		case "/qnaDetailAction_admin.ura":
			action = new QnaDetailAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 답글 뷰 */
		case "/qnaReplyAction.ura":
			action = new QnaReplyView();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
		/** TODO QnA 답글 뷰 */
		case "/qnaReplyAction_admin.ura":
			action = new QnaReplyView_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 답글 액션 */
		case "/qnaReplyView.ura":
			action = new QnaReplyAction();
			try {
			forward = action.execute(request, response);
			} catch (Exception e) {
			e.printStackTrace();
			}
			break;	
			
			/** TODO QnA 답글 액션 */
		case "/qnaReplyView_admin.ura":
			action = new QnaReplyAction_admin();
			try {
			forward = action.execute(request, response);
			} catch (Exception e) {
			e.printStackTrace();
			}
			break;	
			
			
			/** TODO 후기 : 김범주 */
			/** 후기 리스트 액션 */
			/** TODO 후기 리스트 액션 */
		case "/ReviewList.ura":
			action = new ReviewListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 리스트 액션 관리자 */
		case "/ReviewList_admin.ura":
			action = new ReviewListAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 상세보기 액션 */
		case "/ReviewDetailAction.ura":
			action = new ReviewDetailAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 상세보기 액션 */
		case "/ReviewDetailAction_admin.ura":
			action = new ReviewDetailAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 추가 액션 */
		case "/ReviewAddAction.ura":
			action = new ReviewAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 추가 액션 */
		case "/ReviewAddAction_admin.ura":
			action = new ReviewAddAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 수정 페이지 */
		case "/ReviewModify.ura":
			action = new ReviewModifyView();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 수정 페이지 */
		case "/ReviewModify_admin.ura":
			action = new ReviewModifyView_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 수정 액션 */
		case "/ReviewModifyAction.ura":
			action = new ReviewModifyAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 수정 액션 */
		case "/ReviewModifyAction_admin.ura":
			action = new ReviewModifyAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 삭제 액션 */
		case "/ReviewDeleteAction.ura":
			action = new ReviewDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 삭제 액션 */
		case "/ReviewDeleteAction_admin.ura":
			action = new ReviewDeleteAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 검색 액션 */
		case "/ReviewSearchAction.ura":
			action = new ReviewSearchAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 검색 액션 */
		case "/ReviewSearchAction_admin.ura":
			action = new ReviewSearchAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 코멘트 추가 액션 */
		case "/ReviewAddCommentAction.ura":
			action = new ReviewAddCommentAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 코멘트 추가 액션 */
		case "/ReviewAddCommentAction_admin.ura":
			action = new ReviewAddCommentAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 코멘트 삭제 액션 */
		case "/ReviewDeleteCommentAction.ura":
			System.out.println("후기 코멘트 삭제");
			action = new ReviewDeleteCommentAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 코멘트 삭제 액션 */
		case "/ReviewDeleteCommentAction_admin.ura":
			System.out.println("후기 코멘트 삭제");
			action = new ReviewDeleteCommentAction_admin();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		/** TODO 후기 쓰기 액션 */
		case "/ReviewWrite.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./review/write.jsp");
			break;

		/** TODO 후기 쓰기 액션 */
		case "/ReviewWrite_admin.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./review/write_admin.jsp");
			break;
			
			
			/** TODO 공지사항 : 권대홍 */
			/** 공지사항 페이지 */
		case "/noticeWrite.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/notice/noticeWrite.jsp");
			break;
			
			/** 공지사항 페이지 삭제 */
		case "/noticeDelete.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/notice/noticeDelete.jsp");
			break;
			
			/** 공지사항 수정 페이지 */
		case "/noticeModify.ura":
			action = new NoticeModifyView();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 추가 액션 */
		case "/noticeAddAction.ura":
			action = new NoticeAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 수정 액션 */
		case "/noticeModifyAction.ura":
			action = new NoticeModifyAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 삭제 액션 */
		case "/noticeDeleteAction.ura":
			action = new NoticeDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 목록 액션 */
		case "/noticeList.ura":
			action = new NoticeListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 고객화면 */
		case "/serviceList.ura":
			action = new ServiceListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 고객 상세보기 */
		case "/ServiceDetailAction.ura":
			action = new ServiceDetailAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 공지사항 상세보기 액션 */
		case "/noticeDetailAction.ura":
			action = new NoticeDetailAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

			
			/** TODO 예약 : 이영광 */
			/** 전시 일정 페이지 */
		case "/event.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./reserve/res_event.jsp");
			break;
			
			/** 전시 일정 상세 액션 */
		case "/detail.ura":
			action = new ResDetailAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 예약 페이지 */
		case "/reserve.ura":
			action = new ResFormAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 예약 액션 */
		case "/resinsert.ura":
			action = new ResInsertAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 목록 페이지 */
		case "/res_adminReserveList.ura":
			action = new ResAdminRserveListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 예약 취소 액션 */
		case "/resdelete.ura":
			action = new ResDeleteActon();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 유저 예약 목록 액션 */
		case "/resUserCheckList.ura":
			action = new ResUserCheckListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 액션 */
		case "/res_adminInsert.ura":
			action = new ResAdminInsertAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 폼 **/
		case "/res_adminInsertForm.ura":
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./reserve/res_adminInsertForm.jsp");
			break;
			
			/** 관리자 예약 삭제 액션 */
		case "/res_adminDelete.ura":
			action = new ResAdminDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 상세 액션 **/
		case "/res_adminDetail.ura":
			action = new ResAdminDetailAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 수정 액션 **/
		case "/res_adminUpdate.ura":
			action = new ResAdminUpdateAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			/** 관리자 예약 수정 폼 **/
		case "/res_userUpDetailForm.ura":
			forward = new ActionForward();
			String r_num=(String)request.getParameter("r_num");
			forward.setRedirect(false);
			forward.setPath("./reserve/res_userUpDetailForm.jsp");
			break;
			
		case "/res_userUpdate.ura":
			action = new ResUserUpdateAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
			
			/** TODO 디폴트 */
		default: // 위 조건 외에 *.ura로 끝나는 모든 uri는 사용자 인덱스 페이지로 이동
			forward = new ActionForward();
			forward.setRedirect(true);
			forward.setPath("index.ura");
			break;
		}
		
		// 페이지 이동
		if (forward != null) {
			if (forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}

}
