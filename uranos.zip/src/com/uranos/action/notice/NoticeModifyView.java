package com.uranos.action.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;
import com.uranos.model.NoticeVO;

public class NoticeModifyView implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();
		NoticeVO noticedata = new NoticeVO();
		
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		noticedata.setN_num(num);
		noticedata = NoticeDAO.getDetail(noticedata);
		
		if (noticedata == null) {
			System.out.println("수정페이지 진입실패");
			return null;
		}
		System.out.println("수정페이지 진입");
		
		request.setAttribute("noticedata", noticedata);
		
		request.setAttribute("pageNo",pageNo);
		forward.setRedirect(false);
		forward.setPath("./notice/noticeModify.jsp");
		return forward;
	}

}
