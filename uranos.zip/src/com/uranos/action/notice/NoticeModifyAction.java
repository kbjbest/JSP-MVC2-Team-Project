package com.uranos.action.notice;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;
import com.uranos.model.NoticeVO;


public class NoticeModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();
		NoticeVO noticedata = new NoticeVO();
		
		request.setCharacterEncoding("UTF-8");
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		boolean result = false;
		
		
		try {
			noticedata.setN_num(num);
			noticedata.setN_title(request.getParameter("N_title"));
			noticedata.setN_content(request.getParameter("N_content"));
			
			result = NoticeDAO.setNoticeModify(noticedata);
			
			if (result == false) {
				System.out.println("게시판 수정 실패");
				return null;
			}
			System.out.println("게시판 수정 완료");
			
			forward.setRedirect(true);
			forward.setPath("./noticeDetailAction.ura?num=" + num + "&pageNo=" + pageNo);
			System.out.println(noticedata.getN_num());
			return forward;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
