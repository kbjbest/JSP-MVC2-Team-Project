package com.uranos.action.notice;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;

public class NoticeListAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		List noticelist = new ArrayList();
		String tempNo = request.getParameter("pageNo");
		int pageNo=1;
		try {
			pageNo = Integer.parseInt(tempNo);
		} catch (Exception e) {
		}

		final int ROW_PER_PAGE = 10; 
		int begin = (pageNo - 1) * ROW_PER_PAGE + 1;
		int end = pageNo * ROW_PER_PAGE;
		
		noticelist = NoticeDAO.getNoticeList(begin, end);
		
		int totalRows = NoticeDAO.getListCount(); 
		int totalPages = (int) Math.ceil((double) totalRows / ROW_PER_PAGE);
		

		final int PAGE_PER_PAGE = 10; 
		int totalRanges = (int) Math.ceil((double) totalPages / PAGE_PER_PAGE); 
		int currentRange = (int) Math.ceil((double) pageNo / PAGE_PER_PAGE);
		
		int beginPage = (currentRange - 1) * PAGE_PER_PAGE + 1; 
		int endPage = currentRange * PAGE_PER_PAGE;
		if (currentRange == totalRanges)
			endPage = totalPages; 

		int prevPage = 0;
		if (currentRange != 1)
			prevPage = (currentRange - 2) * PAGE_PER_PAGE + 1;
		int nextPage = 0;
		if (currentRange != totalRanges)
			nextPage = currentRange * PAGE_PER_PAGE + 1;

		request.setAttribute("prevPage", prevPage);
		request.setAttribute("nextPage", nextPage);
		request.setAttribute("beginPage", beginPage);
		request.setAttribute("endPage", endPage);
		request.setAttribute("noticelist", noticelist);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalRows", totalRows);
		request.setAttribute("totalPages", totalPages);
		request.setAttribute("totalRanges", totalRanges);
		request.setAttribute("currentRange", currentRange);
		forward.setRedirect(false);
		forward.setPath("notice/noticeList.jsp");

		System.out.println(totalPages);
		return forward;
	}
}