package com.uranos.action.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;

public class NoticeDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();

		boolean result = false;
		int num = Integer.parseInt(request.getParameter("num"));

		result = NoticeDAO.setNoticeDelete(num);
		
		if (result == false) {
			System.out.println("게시판 삭제 실패");
			return null;
		}
		System.out.println("게시판 삭제 성공");

		forward.setRedirect(true);
		forward.setPath("./noticeList.ura");
		return forward;
	}

}
