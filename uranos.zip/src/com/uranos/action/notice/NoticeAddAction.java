package com.uranos.action.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;
import com.uranos.model.NoticeVO;

public class NoticeAddAction implements Action {

	
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		NoticeDAO noticedao = new NoticeDAO();
		NoticeVO noticedata = new NoticeVO();
		ActionForward forward = new ActionForward();
		boolean result=false;
		System.out.println(result);
		
		try {
			request.setCharacterEncoding("utf-8");
			String n_title=request.getParameter("n_title");
			String n_content=request.getParameter("n_content");
			result = NoticeDAO.setNoticeInsert(n_title,n_content);
			
			if (result == false) {
				System.out.println("공지사항 등록실패");
				return null;
			}
			System.out.println("공지사항 등록 완료");
			
			forward.setRedirect(true);
			forward.setPath("./noticeList.ura");
			return forward;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
