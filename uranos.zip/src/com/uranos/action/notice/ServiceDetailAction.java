package com.uranos.action.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.NoticeDAO;
import com.uranos.model.NoticeVO;

public class ServiceDetailAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		NoticeVO noticedata = new NoticeVO();
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		int num = Integer.parseInt(request.getParameter("num"));
		noticedata.setN_num(num);
		noticedata = NoticeDAO.getDetail(noticedata);
		
		
		if (noticedata == null) {
			System.out.println("상세보기 실패");
			return null;
		}
		System.out.println("상세보기 성공");
		noticedata.setN_count(noticedata.getN_count()+1);
		NoticeDAO.setReadCount(noticedata);
		
		
		
		request.setAttribute("num", num);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("noticedata", noticedata);
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./notice/serviceDetail.jsp");
		return forward;
	}

}
