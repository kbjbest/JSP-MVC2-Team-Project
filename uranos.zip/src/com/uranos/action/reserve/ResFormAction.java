package com.uranos.action.reserve;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;

public class ResFormAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = "";
		int m_num=0;
		
		if (session.getAttribute("id") != null) {
			id = (String) session.getAttribute("id");
		}
		
		int num=Integer.parseInt(request.getParameter("num"));
		//m_num=(Integer)session.getAttribute("m_num");
		
		if(id.equals("")){
			forward.setRedirect(false);
			forward.setPath("login.ura");
			return forward;
		}
		
		request.setAttribute("num", num);
		
		forward.setRedirect(false);
		forward.setPath("reserve/res_userInsertForm.jsp");
		
		return forward;
	}
}
