package com.uranos.action.reserve;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ResDAO;
import com.uranos.model.ResVO;

public class ResAdminDeleteAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		
		
		
		ResVO data = new ResVO();
		ResDAO dao=new ResDAO();
		int r_num=Integer.parseInt(request.getParameter("r_num"));
		
		data.setR_num(r_num);
		dao.delete(data);

		forward.setRedirect(true);
		forward.setPath("res_adminReserveList.ura");
		
		return forward;
	}
}
