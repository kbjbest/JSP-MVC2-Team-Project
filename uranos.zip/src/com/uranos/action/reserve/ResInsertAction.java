package com.uranos.action.reserve;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ResDAO;
import com.uranos.model.ResVO;

public class ResInsertAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		
		
		
		String start = request.getParameter("start");
		String title = request.getParameter("name");
		String time = request.getParameter("time");
		int m_num=Integer.parseInt(request.getParameter("m_num"));
		
		Date date = Date.valueOf(start);
		ResVO data = new ResVO();
		ResDAO dao=new ResDAO();
		
		data.setR_start(date);
		data.setR_time(time);
		data.setR_name(title);
		data.setM_num(m_num);
		dao.insert(data);
		
		
		forward.setRedirect(true);
		forward.setPath("resUserCheckList.ura");
		
		return forward;
		
		
		
	}
}
