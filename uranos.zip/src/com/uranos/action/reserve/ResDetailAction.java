package com.uranos.action.reserve;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;

public class ResDetailAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		/*
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		*/
		String id = null;
		int num=Integer.parseInt(request.getParameter("num"));
		
		if(id==null){
			forward.setRedirect(false);
			forward.setPath("reserve/res_detail.jsp");
			return forward;
		}
		
		request.setAttribute("num", num);
		
		forward.setRedirect(false);
		forward.setPath("reserve/res_detail.jsp");
		
		return forward;
		
	}
}