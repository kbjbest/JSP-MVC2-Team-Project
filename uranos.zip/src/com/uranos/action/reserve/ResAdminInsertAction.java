package com.uranos.action.reserve;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;
import com.uranos.model.MemberVO;
import com.uranos.model.ResDAO;
import com.uranos.model.ResVO;

public class ResAdminInsertAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		String m_id = request.getParameter("m_id");
		String start = request.getParameter("start");
		String title = request.getParameter("list");
		String time = request.getParameter("time");
		
		
		
		Date date = Date.valueOf(start);
		
		MemberVO m_data = new MemberVO();
		ResVO data = new ResVO();
		ResDAO dao=new ResDAO();
		
		m_data = MemberDAO.member_info(m_id);
		
		int m_num=m_data.getM_num();
		
		
		
		
		data.setM_num(m_num);
		data.setR_start(date);
		data.setR_time(time);
		data.setR_name(title);
		dao.insert(data);
		
		
		forward.setRedirect(true);
		forward.setPath("res_adminReserveList.ura");
		
		return forward;
		
	}
}
