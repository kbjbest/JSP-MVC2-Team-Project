package com.uranos.action.reserve;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;

public class ResAdminDetailAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");
		/*
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		*/
		
		int r_num=Integer.parseInt(request.getParameter("r_num"));
		String m_id = request.getParameter("m_id");
		
		forward.setRedirect(false);
		forward.setPath("reserve/res_admindetail.jsp");
		
		return forward;
		
	}
}
