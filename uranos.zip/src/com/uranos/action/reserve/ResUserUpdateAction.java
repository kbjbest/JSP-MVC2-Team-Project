package com.uranos.action.reserve;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberVO;
import com.uranos.model.ResDAO;
import com.uranos.model.ResVO;

public class ResUserUpdateAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");

		int r_num = Integer.parseInt(request.getParameter("r_num"));
		String start = request.getParameter("r_start");
		String r_time = request.getParameter("r_time");

		Date r_start = Date.valueOf(start);

		ResVO data = new ResVO();
		
		data.setR_num(r_num);
		data.setR_start(r_start);
		data.setR_time(r_time);
		
		ResDAO.userUpdate(data);

		forward.setRedirect(true);
		forward.setPath("resUserCheckList.ura");

		return forward;

	}
}
