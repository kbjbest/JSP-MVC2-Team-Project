package com.uranos.action.reserve;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.ResDAO;

public class ResUserCheckListAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("UTF-8");		


		HttpSession session = request.getSession();
		String id = "";
		int m_num=0;
		
		
		if(session.getAttribute("m_num")!=null){
			m_num=(Integer)session.getAttribute("m_num");
		}else{
			forward.setRedirect(true);
			forward.setPath("login.ura");
			return forward;
		}
		
		if (session.getAttribute("id") != null) {
			id = (String) session.getAttribute("id");
		}else{
			forward.setRedirect(true);
			forward.setPath("login.ura");
			return forward;
		}
		
		
		
		
		List reslist = new ArrayList();
		
		int page = 1;
		int limit = 10;

		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}
		int listcount = ResDAO.getUserListCount(m_num);
		reslist = ResDAO.getResUserList(page, limit,m_num);

		int maxpage = (int) ((double) listcount / limit + 0.95);

		int startpage = (((int) ((double) page / 10 + 0.9)) - 1) * 10 + 1;

		int endpage = maxpage;

		if (endpage > startpage + 10 - 1)
			endpage = startpage + 10 - 1;

		request.setAttribute("res_userPage", page);
		request.setAttribute("res_userMaxpage", maxpage);
		request.setAttribute("res_userStartpage", startpage);
		request.setAttribute("res_userEndpage", endpage);
		request.setAttribute("res_userListcount", listcount);
		request.setAttribute("res_userlist", reslist);
		
		
		forward.setRedirect(false);
		forward.setPath("reserve/res_userCheckList.jsp");
		
		return forward;
	}
}
