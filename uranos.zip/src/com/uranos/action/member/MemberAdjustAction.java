package com.uranos.action.member;

import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;
import com.uranos.model.MemberVO;

public class MemberAdjustAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		MemberVO mem = new MemberVO();
		int num = Integer.parseInt(request.getParameter("num"));
		int grade = (Integer) request.getSession().getAttribute("grade");
		
		if (request.getParameter("isPwCheck") != null) { // 비밀번호 변경 안함
			mem.setM_pw(request.getParameter("origPw"));
			
		} else { // 비밀번호 변경 함
			mem.setM_pw(request.getParameter("m_pw"));
		}
		
		mem.setM_name(request.getParameter("m_name"));
		mem.setM_nick(request.getParameter("m_nick"));
		mem.setM_tel(request.getParameter("m_tel"));
		
		try {
			mem.setM_birth(Date.valueOf( request.getParameter("m_birth") ));
		} catch (Exception e) {
			mem.setM_birth(Date.valueOf("1000-01-01"));
		}
		
		mem.setM_email(request.getParameter("m_email"));
		mem.setM_addr1(request.getParameter("m_addr1"));
		mem.setM_addr2(request.getParameter("m_addr2"));
		
		if (grade == 0) {
			mem.setM_num(num);
		} else {
			mem.setM_num((Integer) request.getSession().getAttribute("m_num"));
		}
				
		PrintWriter out = response.getWriter();
		
		if (MemberDAO.member_adjust(mem)) {
			out.println("<script>");
			out.print("alert('회원정보 수정이 완료되었습니다.');");
			
			if ((Integer) request.getSession().getAttribute("grade") == 0) {
				out.println("location.href='memberDetail_admin.ura?num=" + num + "';");
			} else {
				out.println("location.href='mypage.ura?mypage=memberInfo';");				
			}
			
			out.println("</script>");
			
		} else {
			out.print("<script>");
			out.print("alert('회원정보 수정을 실패했습니다.');");
			out.println("history.go(-1);");
			out.print("</script>");
		}
		
		out.close();
		
		return null;
	}
	
}
