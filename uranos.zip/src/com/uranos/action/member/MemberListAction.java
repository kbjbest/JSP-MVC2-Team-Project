package com.uranos.action.member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;

public class MemberListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();
		
		List memberList = new ArrayList();
		String tempNo = request.getParameter("pageNo");
		int pageNo=1;
		try {
			pageNo = Integer.parseInt(tempNo);
		} catch (Exception e) {}

		final int ROW_PER_PAGE = 10; 
		int begin = (pageNo - 1) * ROW_PER_PAGE + 1;
		int end = pageNo * ROW_PER_PAGE;
		
		memberList = MemberDAO.member_list_page(begin, end);
		int totalRows = MemberDAO.member_count(); 
		int totalPages = (int) Math.ceil((double) totalRows / ROW_PER_PAGE);
		

		final int PAGE_PER_PAGE = 10; 
		int totalRanges = (int) Math.ceil((double) totalPages / PAGE_PER_PAGE); 
		int currentRange = (int) Math.ceil((double) pageNo / PAGE_PER_PAGE);
		
		int beginPage = (currentRange - 1) * PAGE_PER_PAGE + 1; 
		int endPage = currentRange * PAGE_PER_PAGE;
		if (currentRange == totalRanges)
			endPage = totalPages; 

		int prevPage = 0;
		if (currentRange != 1){
			prevPage = (currentRange - 2) * PAGE_PER_PAGE + 1;			
		}
		
		int nextPage = 0;
		if (currentRange != totalRanges) {
			nextPage = currentRange * PAGE_PER_PAGE + 1;			
		}
		
		request.setAttribute("prevPage", prevPage);
		request.setAttribute("nextPage", nextPage);
		request.setAttribute("beginPage", beginPage);
		request.setAttribute("endPage", endPage);
		request.setAttribute("memberList", memberList);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalRows", totalRows);
		request.setAttribute("totalPages", totalPages);
		request.setAttribute("totalRanges", totalRanges);
		request.setAttribute("currentRange", currentRange);
		
		forward.setRedirect(false);
		forward.setPath("member/member_management_admin.jsp");
		
		return forward;
	}
	
}
