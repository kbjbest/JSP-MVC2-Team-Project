package com.uranos.action.member;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;
import com.uranos.model.MemberVO;

public class MemberLoginAction implements Action {

	@SuppressWarnings("unchecked")
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		MemberVO mem = new MemberVO();

		String id = request.getParameter("m_id");
		String pw = request.getParameter("m_pw");
		int grade = request.getParameter("grade").equals("admin") ? 0 : 1;
		
		Map<String, String[]> map = null;
		String qry = "";
		String uri = "index.ura";
		
		HttpSession session = request.getSession();
		if (session.getAttribute("qry_string") != null) {
			map = (Map<String, String[]>) session.getAttribute("qry_string");
			Set<Entry<String, String[]>> set = map.entrySet();
			Iterator<Entry<String, String[]>> it = set.iterator();
			
			// 이동하고자 하는 페이지가 있을 때
			if (map.containsKey("uri")) {
				uri = map.get("uri")[0];
				
				qry = "?";
				while (it.hasNext()) {
					Map.Entry<String, String[]> e = (Map.Entry<String, String[]>) it.next();
					if (!e.getKey().equals("uri")) {
//						System.out.println("이름 : " + e.getKey() + ", 값 : " + e.getValue()[0]);
						qry += e.getKey() + "=" + e.getValue()[0] + "&";
					}
				}
				qry = qry.substring(0, qry.length() - 1);
				
			} else { // 이동하고자 하는 페이지가 없을 때
//				uri = (String) session.getAttribute("uri"); // 보고 있던 페이지로 넘어감
//				qry = "";
			}	
		}
		
		mem.setM_id(id);
		mem.setM_pw(pw);
		mem.setM_grade(grade);
		
		PrintWriter out = response.getWriter();
		
		if (MemberDAO.member_check(mem)) {
			System.out.println(id);
			mem = MemberDAO.member_info(id);
			
			session.setAttribute("id", mem.getM_id());
			session.setAttribute("nick", mem.getM_nick());
			session.setAttribute("grade", grade);
			session.setAttribute("m_num", mem.getM_num());
			
			session.removeAttribute("qry_string"); // 세션에서 임시로 저장한 값 삭제
			session.removeAttribute("uri");
			System.out.println(uri + ( qry.equals("?") ? "" : qry ));
			
			out.println("<script>");
			out.println("location.href='" + uri + ( qry.equals("?") ? "" : qry ) + "';");
			out.println("</script>");
			
		} else {
			out.print("<script>");
			out.print("alert('아이디나 비밀번호가 일치하지 않습니다!');");
			out.println("history.go(-1);");
			out.print("</script>");
		}
		
		out.close();
		return null;
	}
	
}
