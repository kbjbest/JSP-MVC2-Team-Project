package com.uranos.action.qna;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.QnaDAO;
import com.uranos.model.QnaVO;

public class QnaAddAction implements Action {

	
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		QnaVO qnadata = new QnaVO();
		ActionForward forward = new ActionForward();
		boolean result=false;
	
		try {
			request.setCharacterEncoding("utf-8");
			String Q_title=request.getParameter("Q_title");
			String Q_content=request.getParameter("Q_content");
			int M_num=(Integer)request.getSession().getAttribute("m_num");
			int Q_orignum=QnaDAO.getMaxNum() + 1;
			
			qnadata.setQ_title(Q_title);
			qnadata.setQ_content(Q_content);
			qnadata.setM_num(M_num);
			qnadata.setQ_orignum(Q_orignum);

			result = QnaDAO.setQnaInsert(qnadata);
			

			if (result == false) {
				System.out.println("게시판 등록실패");
				return null;
			}
			System.out.println("게시판 등록 완료");
			
			forward.setRedirect(true);
			forward.setPath("./qnaList.ura");
			return forward;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	}
