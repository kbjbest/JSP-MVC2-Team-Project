package com.uranos.action.qna;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.QnaDAO;
import com.uranos.model.QnaVO;

public class QnaReplyView implements Action {
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		QnaVO qnadata = new QnaVO();

		int num = Integer.parseInt(request.getParameter("num"));

		qnadata = QnaDAO.getDetailReply(num);

		if (qnadata == null) {
			System.out.println("답변보기성공");
			return null;
		}
		System.out.println("답변보기 실패");
		request.setAttribute("qnadata", qnadata);

		forward.setRedirect(false);
		forward.setPath("./qna/qnaReply.jsp");
		return forward;
	}
}