package com.uranos.action.qna;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;
import com.uranos.model.QnaDAO;

public class QnaDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();

		boolean result = false;
		//boolean usercheck = false;
		int num = Integer.parseInt(request.getParameter("num"));
		
	    HttpSession session = request.getSession();
		
	    /*
	    String m_nick = (String) session.getAttribute("nick");
		
		usercheck = MemberDAO.member_nick_check(m_nick);

	      if(usercheck != false ) {
	         response.setContentType("text/html;charset=UTF-8");
	         PrintWriter out = response.getWriter();
	         out.println("<script>");
	         out.println("alert('삭제할 권한이 없습니다.');");
	         out.println(" location.href='./QnaDetailAction.ura?num=" +num+"' ");
	         out.println("</script>");
	         out.close();
	         return null;
	      }*/
	      
	  	result = QnaDAO.setQnaDelete(num);
		
		if (result == false) {
			System.out.println("게시판 삭제 실패");
			return null;
		}
		System.out.println("게시판 삭제 성공");

		forward.setRedirect(true);
		forward.setPath("./qnaList.ura");
		return forward;
	}

}