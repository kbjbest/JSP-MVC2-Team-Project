package com.uranos.action.qna;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.QnaDAO;

public class QnaDeleteAction_admin implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();

		boolean result = false;
		int num = Integer.parseInt(request.getParameter("num"));

		result = QnaDAO.setQnaDelete(num);
		
		if (result == false) {
			System.out.println("게시판 삭제 실패");
			return null;
		}
		System.out.println("게시판 삭제 성공");

		forward.setRedirect(true);
		forward.setPath("./qnaList_admin.ura");
		return forward;
	}

}