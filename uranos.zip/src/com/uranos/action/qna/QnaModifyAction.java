package com.uranos.action.qna;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.MemberDAO;
import com.uranos.model.QnaDAO;
import com.uranos.model.QnaVO;


public class QnaModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		QnaVO qnadata = new QnaVO();
		
		request.setCharacterEncoding("UTF-8");
		int num = Integer.parseInt(request.getParameter("num"));
		
		boolean result = false;
		boolean usercheck = false;
		
		HttpSession session = request.getSession();
		/*String m_nick = (String) session.getAttribute("nick");
			
		(usercheck = MemberDAO.member_nick_check(m_nick);
	
	      if(usercheck != false ) {
	         response.setContentType("text/html;charset=UTF-8");
	         PrintWriter out = response.getWriter();
	         out.println("<script>");
	         out.println("alert('수정할 권한이 없습니다.');");
	         out.println(" location.href='./QnaDetailAction.ura?num=" +num+"' ");
	         out.println("</script>");
	         out.close();
	         return null;
	      }
		*/
		
		try {
			qnadata.setQ_num(num);
			qnadata.setQ_title(request.getParameter("Q_title"));
			String q_title = request.getParameter("Q_title");
			System.out.println(q_title);
			qnadata.setQ_content(request.getParameter("Q_content"));
			String Q_content = request.getParameter("Q_content");
			System.out.println(Q_content);
			
			result =  QnaDAO.setQnaModify(qnadata);
			
			if (result == false) {
				System.out.println("게시판 수정 실패");
				return null;
			}
			System.out.println("게시판 수정 완료");
			
			forward.setRedirect(true);
			forward.setPath("./qnaDetailAction.ura?num=" + qnadata.getQ_num());
			return forward;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
