package com.uranos.action.qna;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.QnaDAO;
import com.uranos.model.QnaVO;

public class QnaReplyAction_admin implements Action {
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = new ActionForward();

		QnaVO qnadata = new QnaVO();
		
		int q_num = Integer.parseInt(request.getParameter("Q_orignum"));
		
		qnadata.setQ_title(request.getParameter("Q_title"));
		qnadata.setQ_content(request.getParameter("Q_content"));
		qnadata.setQ_orignum(Integer.parseInt(request.getParameter("Q_orignum")));
		qnadata.setQ_level(1);
		qnadata.setM_num((Integer)request.getSession().getAttribute("m_num"));
		
		if (!QnaDAO.setQnaInsert(qnadata)) {
			return null;
		}

		forward.setRedirect(true);
		forward.setPath("./qnaDetailAction_admin.ura?num=" + q_num);
		return forward;
	}
}