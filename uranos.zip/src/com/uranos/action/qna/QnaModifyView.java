package com.uranos.action.qna;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uranos.action.Action;
import com.uranos.action.ActionForward;
import com.uranos.model.QnaDAO;
import com.uranos.model.QnaVO;

public class QnaModifyView implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		QnaVO qnadata = new QnaVO();
		
		int num = Integer.parseInt(request.getParameter("num"));
		qnadata.setQ_num(num);
		qnadata =QnaDAO.getDetail(qnadata);
		
		if (qnadata == null) {
			System.out.println("(수정)상세보기 실패");
			return null;
		}
		System.out.println("(수정)상세보기 성공");
		
		request.setAttribute("qnadata", qnadata);
		
		forward.setRedirect(false);
		forward.setPath("./qna/qnaModify.jsp");
		return forward;
	}

}
