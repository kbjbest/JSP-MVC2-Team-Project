package com.uranos.model;

import java.sql.Date;

public class CommentVO {
	private int co_num, m_num;
	private String co_content;
	private Date co_day;
	private int rw_num;
	private String m_nick;

	public String getM_nick() {
		return m_nick;
	}

	public void setM_nick(String m_nick) {
		this.m_nick = m_nick;
	}

	public CommentVO() {
	}

	public CommentVO(int co_num, int m_num, String co_content, Date co_day, int rw_num) {
		super();
		this.co_num = co_num;
		this.m_num = m_num;
		this.co_content = co_content;
		this.co_day = co_day;
		this.rw_num = rw_num;
	}

	public int getCo_num() {
		return co_num;
	}

	public void setCo_num(int co_num) {
		this.co_num = co_num;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	public String getCo_content() {
		return co_content;
	}

	public void setCo_content(String co_content) {
		this.co_content = co_content;
	}

	public Date getCo_day() {
		return co_day;
	}

	public void setCo_day(Date co_day) {
		this.co_day = co_day;
	}

	public int getRw_num() {
		return rw_num;
	}

	public void setRw_num(int rw_num) {
		this.rw_num = rw_num;
	}

}
