package com.uranos.model;

import java.sql.Date;

public class ResVO {
	private int r_num;
	private Date r_day;
	private Date r_start;
	private String r_name;
	private String r_time;
	private int m_num;
	
	private String m_id;
	
	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public ResVO() {
		// TODO Auto-generated constructor stub
	}
	
	public ResVO(int r_num, Date r_day, Date r_start, String r_name, String r_time, int m_num) {
		super();
		this.r_num = r_num;
		this.r_day = r_day;
		this.r_start = r_start;
		this.r_name = r_name;
		this.r_time = r_time;
		this.m_num = m_num;
	}
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	
	public Date getR_day() {
		return r_day;
	}
	public void setR_day(Date r_day) {
		this.r_day = r_day;
	}
	
	public Date getR_start() {
		return r_start;
	}
	public void setR_start(Date r_start) {
		this.r_start = r_start;
	}
	
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String r_name) {
		this.r_name = r_name;
	}
	
	public String getR_time() {
		return r_time;
	}
	public void setR_time(String r_time) {
		this.r_time = r_time;
	}
	
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}	
}
