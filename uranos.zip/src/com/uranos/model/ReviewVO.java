package com.uranos.model;

import java.sql.Date;

public class ReviewVO {

	private int rw_num;
	private String rw_title, rw_content;
	private Date rw_day;
	private String rw_file;
	private int rw_count, m_num;
	private String m_nick;

	public String getM_nick() {
		return m_nick;
	}

	public void setM_nick(String m_nick) {
		this.m_nick = m_nick;
	}

	public ReviewVO() {
		// TODO Auto-generated constructor stub
	}

	public ReviewVO(int rw_num, String rw_title, String rw_content, Date rw_day, String rw_file, int rw_count,
			int rw_level, int rw_orignum, int m_num) {
		super();
		this.rw_num = rw_num;
		this.rw_title = rw_title;
		this.rw_content = rw_content;
		this.rw_day = rw_day;
		this.rw_file = rw_file;
		this.rw_count = rw_count;
		this.m_num = m_num;
	}

	public int getRw_num() {
		return rw_num;
	}

	public void setRw_num(int rw_num) {
		this.rw_num = rw_num;
	}

	public String getRw_title() {
		return rw_title;
	}

	public void setRw_title(String rw_title) {
		this.rw_title = rw_title;
	}

	public String getRw_content() {
		return rw_content;
	}

	public void setRw_content(String rw_content) {
		this.rw_content = rw_content;
	}

	public Date getRw_day() {
		return rw_day;
	}

	public void setRw_day(Date rw_day) {
		this.rw_day = rw_day;
	}

	public String getRw_file() {
		return rw_file;
	}

	public void setRw_file(String rw_file) {
		this.rw_file = rw_file;
	}

	public int getRw_count() {
		return rw_count;
	}

	public void setRw_count(int rw_count) {
		this.rw_count = rw_count;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

}
