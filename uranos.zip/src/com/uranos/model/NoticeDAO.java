package com.uranos.model;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class NoticeDAO {
	private static SqlSessionFactory sqlSessionFactory;

	static {
		try {
			Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException("SqlSessionFactory Instance. " + e, e);
		}
	}

	public static boolean setNoticeInsert(String n_title,String n_contents) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String,String>();
		map.put("n_title",n_title);
		map.put("n_content",n_contents);
		System.out.println("map");
		int cnt=session.insert("notice_insert",map);
		session.commit();      return(cnt > 0)? true : false; 
	}

	public static List<NoticeVO> getNoticeList(int begin, int end) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String,String>();
		int startrow = begin;
		int endrow = end;
		map.put("startrow",Integer.toString(startrow));
		map.put("endrow", Integer.toString(endrow));
		List<NoticeVO> list = session.selectList("notice_List",map);
		return list;
	}

	public static List<NoticeVO> searchTitle(String title, int begin,int end) {
		
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("n_title", title);
		map.put("startrow",Integer.toString(begin));
		map.put("endrow",Integer.toString(end));
		List<NoticeVO> st = ss.selectList("notice_searchTitle", map);
		return st;
	}
	public static List<NoticeVO> searchContent(String content, int begin,int end) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("n_content", content);
		map.put("startrow",Integer.toString(begin));
		map.put("endrow",Integer.toString(end));
		List<NoticeVO> sc = ss.selectList("notice_searchContent", map);
		return sc;
	}
	public static List<NoticeVO> searchTitleContent(String search, int begin,int end) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("n_title", search);
		map.put("n_content", search);
		map.put("startrow",Integer.toString(begin));
		map.put("endrow",Integer.toString(end));
		List<NoticeVO> stc = ss.selectList("notice_searchTitleContent", map);
		return stc;
	}
	
	public static int getListCount() {
		SqlSession session = sqlSessionFactory.openSession();
		int count = (Integer) session.selectOne("notice_listCount");
		return count;
	}

	public static boolean isNoticeNum(int num) {
		SqlSession session = sqlSessionFactory.openSession();
		int isnum = (Integer) session.selectOne("notice_isNum");
		return true;
	}

	public static boolean setNoticeModify(NoticeVO notice) {
		SqlSession session = sqlSessionFactory.openSession();
		session.update("notice_modify", notice);
		session.commit();
		return true;
		
	}

	public static int setReadCount(NoticeVO count) {
		SqlSession session = sqlSessionFactory.openSession();
		int cnt = session.update("notice_readCount", count);
		session.commit();
		return cnt;
	}

	public static boolean setNoticeDelete(int num) {
		SqlSession session = sqlSessionFactory.openSession();
		session.delete("notice_delete", num);
		session.commit();
		return true;

	}

	public static NoticeVO getDetail(NoticeVO num) {
		SqlSession session = sqlSessionFactory.openSession();
		NoticeVO noticevo = (NoticeVO) session.selectOne("notice_detail", num);
		session.commit();
		return noticevo;
	}
	public static NoticeVO getView(String n_title,String n_day) {
		SqlSession session = sqlSessionFactory.openSession();
		NoticeVO view = (NoticeVO) session.selectList("notice_ViewBox");
		session.commit();
		return view;
	}
	}
