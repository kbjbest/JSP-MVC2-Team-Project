package com.uranos.model;
import java.sql.Date;
public class NoticeVO {
	private int n_num;
	private String n_title;
	private String n_content;
	private java.sql.Date n_day;
	private int n_count;
	public NoticeVO(){ }
	public NoticeVO(int n_num,String n_title,String n_content,Date n_day,int n_count){
	super();                    
	this.n_num=n_num;  
	this.n_title=n_title;
	this.n_content=n_content;   
	this.n_day=n_day;  
	this.n_count=n_count;
	}
	public int getN_num() {
		return n_num;
	}
	public void setN_num(int n_num) {
		this.n_num = n_num;
	}
	public String getN_title() {
		return n_title;
	}
	public void setN_title(String n_title) {
		this.n_title = n_title;
	}
	public String getN_content() {
		return n_content;
	}
	public void setN_content(String n_content) {
		this.n_content = n_content;
	}
	public java.sql.Date getN_day() {
		return n_day;
	}
	public void setN_day(java.sql.Date n_day) {
		this.n_day = n_day;
	}
	public int getN_count() {
		return n_count;
	}
	public void setN_count(int n_count) {
		this.n_count = n_count;
	}
	
}
