package com.uranos.model;

import java.sql.Date;

public class MemberVO {

	private int m_num, m_grade;
	private String m_id, m_pw, m_name, m_nick, m_gender, m_email, m_tel, m_addr1, m_addr2;
	private Date m_birth;
	
	public MemberVO() {
		// TODO Auto-generated constructor stub
	}

	public MemberVO(int m_num, String m_id, String m_pw, String m_name, String m_nick, int m_grade, String m_gender,
			Date m_birth, String m_email, String m_tel, String m_addr1, String m_addr2) {
		super();
		this.m_num = m_num;
		this.m_id = m_id;
		this.m_pw = m_pw;
		this.m_name = m_name;
		this.m_nick = m_nick;
		this.m_grade = m_grade;
		this.m_gender = m_gender;
		this.m_birth = m_birth;
		this.m_email = m_email;
		this.m_tel = m_tel;
		this.m_addr1 = m_addr1;
		this.m_addr2 = m_addr2;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	public int getM_grade() {
		return m_grade;
	}

	public void setM_grade(int m_grade) {
		this.m_grade = m_grade;
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public String getM_pw() {
		return m_pw;
	}

	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_nick() {
		return m_nick;
	}

	public void setM_nick(String m_nick) {
		this.m_nick = m_nick;
	}

	public String getM_gender() {
		return m_gender;
	}

	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}

	public String getM_tel() {
		return m_tel;
	}

	public void setM_tel(String m_tel) {
		this.m_tel = m_tel;
	}

	public String getM_addr1() {
		return m_addr1;
	}

	public void setM_addr1(String m_addr1) {
		this.m_addr1 = m_addr1;
	}

	public String getM_addr2() {
		return m_addr2;
	}

	public void setM_addr2(String m_addr2) {
		this.m_addr2 = m_addr2;
	}

	public Date getM_birth() {
		return m_birth;
	}

	public void setM_birth(Date m_birth) {
		this.m_birth = m_birth;
	}
	
}
