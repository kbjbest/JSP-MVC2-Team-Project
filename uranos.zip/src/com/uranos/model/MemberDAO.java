package com.uranos.model;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MemberDAO {

private static SqlSessionFactory sqlSessionFactory;
	
	static {
		try {
			Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException("SqlSessionFactory instance. " + e, e);
		}
	}
	
	/**
	 * 회원 목록 가져오기
	 * @return 회원 목록(M_num 기준 오름차순)
	 */
	public static List<MemberVO> member_list() {
		SqlSession session = sqlSessionFactory.openSession();
		List<MemberVO> list = session.selectList("member_list");
		session.close();
		return list;
	}
	
	public static List<MemberVO> member_list_page(int startrow, int endrow) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Integer> map = new HashMap<>();
		map.put("startrow", startrow);
		map.put("endrow", endrow);
		List<MemberVO> list = session.selectList("member_list_page", map);
		session.close();
		return list;
	}
	
	public static int member_count() {
		SqlSession session = sqlSessionFactory.openSession();
		int result = session.selectOne("member_count");
		session.close();
		return result;
	}
	
	public static MemberVO member_info(String m_id) {
		SqlSession session = sqlSessionFactory.openSession();
		MemberVO mem = (MemberVO) session.selectOne("member_info_id", m_id);
		session.close();
		return mem;
	}
	
	public static MemberVO member_info(int m_num) {
		SqlSession session = sqlSessionFactory.openSession();
		MemberVO mem = (MemberVO) session.selectOne("member_info_num", m_num);
		session.close();
		return mem;
	}
	
	public static boolean member_check(MemberVO mem) {
		SqlSession session = sqlSessionFactory.openSession();
		mem = (MemberVO) session.selectOne("member_check", mem);
		session.close();
		return (mem != null) ? true : false;
	}
	
	public static boolean member_nick_check(String m_nick) {
		SqlSession session = sqlSessionFactory.openSession();
		MemberVO isNick = (MemberVO) session.selectOne("member_nick_check", m_nick);
		session.close();
		return isNick != null ? true : false;
	}
	
	public static int member_signup(MemberVO mem) {
		SqlSession session = sqlSessionFactory.openSession();
		int result = session.insert("member_signup", mem);
		session.commit();
		session.close();
		return result;
	}
	
	public static boolean member_adjust(MemberVO mem) {
		SqlSession session = sqlSessionFactory.openSession();
		int result = session.update("member_adjust", mem);
		session.commit();
		session.close();
		return result == 1 ? true : false;
	}
	
	public static boolean member_signout(int m_num) {
		SqlSession session = sqlSessionFactory.openSession();
		int result = session.delete("member_signout", m_num);
		session.commit();
		session.close();
		return result == 1 ? true : false;
	}

}
