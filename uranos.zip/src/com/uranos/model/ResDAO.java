package com.uranos.model;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ResDAO {
	private static SqlSessionFactory sqlSessionFactory;

	static {
		try {
			Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException("SqlSessionFactory instance. " + e, e);
		}
	}

	public static void insert(ResVO res) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();
		map.put("name", res.getR_name());
		map.put("start", res.getR_start());
		map.put("time", res.getR_time());
		map.put("m_num", res.getM_num());
		session.insert("reserve.insert", map);
		session.commit();
		session.close();
	}

	public static void delete(ResVO res) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();
		map.put("r_num", res.getR_num());
		session.delete("reserve.delete", map);
		session.commit();
		session.close();
	}

	public static int getListCount() {
		SqlSession session = sqlSessionFactory.openSession();
		int x = (Integer) session.selectOne("res_count");
		session.close();
		return x;
	}

	public static int getUserListCount(int m_num) {
		SqlSession session = sqlSessionFactory.openSession();
		int x = (Integer) session.selectOne("res_userCount", m_num);
		session.close();
		return x;
	}

	public static List<ResVO> getResList(int page, int limit) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();
		int startrow = (page - 1) * 10 + 1;
		int endrow = startrow + limit - 1;
		System.out.println(startrow + " " + endrow);
		map.put("startrow", Integer.toString(startrow));
		map.put("endrow", Integer.toString(endrow));
		// map.put("m_num", m_num);
		List<ResVO> list = session.selectList("resList", map);
		session.close();
		return list;
	}

	public static List<ResVO> getResUserList(int page, int limit, int m_num) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();

		int startrow = (page - 1) * 10 + 1;
		int endrow = startrow + limit - 1;

		System.out.println(startrow + " " + endrow);
		map.put("startrow", Integer.toString(startrow));
		map.put("endrow", Integer.toString(endrow));
		map.put("m_num", Integer.toString(m_num));

		List<ResVO> list = session.selectList("resUserList", map);
		session.close();

		return list;
	}

	public static ResVO reserve_info(String r_num) {
		SqlSession session = sqlSessionFactory.openSession();
		System.out.println("다오의 r_num" + r_num);
		ResVO res = (ResVO) session.selectOne("reserve_info", r_num);
		session.close();
		return res;
	}

	public static List<ResVO> list() {

		List<ResVO> list = null;
		SqlSession session = sqlSessionFactory.openSession();
		list = session.selectList("list");
		session.close();
		return list;
	}

	public static List<ResVO> getReserveInfoByMnum(int m_num) {
		SqlSession session = sqlSessionFactory.openSession();
		List<ResVO> list = session.selectList("getReserveInfoByMnum", m_num); 
		session.close();
		return list;
	}

	public static void adminUpdate(ResVO vo) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();

		map.put("r_num", vo.getR_num());
		map.put("r_name", vo.getR_name());
		map.put("r_start", vo.getR_start());
		map.put("r_time", vo.getR_time());

		session.update("reserve.res_adminUpdate", map);
		session.commit();
		session.close();
	}

	public static void userUpdate(ResVO vo) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, Object> map = new HashMap<>();

		map.put("r_num", vo.getR_num());
		map.put("r_start", vo.getR_start());
		map.put("r_time", vo.getR_time());

		session.update("reserve.res_userUpdate", map);
		session.commit();
		session.close();
	}
}
