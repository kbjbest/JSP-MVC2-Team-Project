package com.uranos.model;

public class QnaVO {
	private int Q_num;
	private String Q_title;
	private String Q_content;
	private java.sql.Date Q_day;
	private int Q_orignum;
	private int Q_level;
	private int M_num;
	private int Q_count;
	private String M_nick;
	
	
	public String getM_nick() {
		return M_nick;
	}
	public void setM_nick(String m_nick) {
		M_nick = m_nick;
	}
	public int getQ_num() {
		return Q_num;
	}
	public void setQ_num(int q_num) {
		Q_num = q_num;
	}
	public String getQ_title() {
		return Q_title;
	}
	public void setQ_title(String q_title) {
		Q_title = q_title;
	}
	public String getQ_content() {
		return Q_content;
	}
	public void setQ_content(String q_content) {
		Q_content = q_content;
	}
	public java.sql.Date getQ_day() {
		return Q_day;
	}
	public void setQ_day(java.sql.Date q_day) {
		Q_day = q_day;
	}
	public int getQ_orignum() {
		return Q_orignum;
	}
	public void setQ_orignum(int q_orignum) {
		Q_orignum = q_orignum;
	}
	public int getQ_level() {
		return Q_level;
	}
	public void setQ_level(int q_level) {
		Q_level = q_level;
	}
	public int getM_num() {
		return M_num;
	}
	public void setM_num(int m_num) {
		M_num = m_num;
	}
	public int getQ_count() {
		return Q_count;
	}
	public void setQ_count(int q_count) {
		Q_count = q_count;
	}
	
}