package com.uranos.model;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ReviewDAO {
	private static ReviewDAO dao = new ReviewDAO();

	private static SqlSessionFactory sqlSessionFactory;

	static {
		try {
			Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException("SqlSessionFactory instance. " + e, e);
		}
	}

	public static List<ReviewVO> list() {
		SqlSession ss = sqlSessionFactory.openSession();
		List<ReviewVO> list = ss.selectList("review_list");
		return list;
	}

	private ReviewDAO() {
	}

	public static int getListCount() {
		SqlSession ss = sqlSessionFactory.openSession();
		int x = (Integer) ss.selectOne("review_count");
		return x;
	}

	public static int getListSearchCount(String search) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", search);
		System.out.println("getListSearchCount" + search);
		int x = (Integer) ss.selectOne("review_searchtitlecount", map);
		System.out.println(x);
		return x;
	}

	public static List<ReviewVO> getBoardList(int page, int limit) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("startrow", Integer.toString(page));
		map.put("endrow", Integer.toString(limit));
		List<ReviewVO> list = ss.selectList("review_boardlist", map);
		return list;
	}

	public static List<ReviewVO> searchTitle(String search, int page, int limit) {
		System.out.println(search);
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", search);
		map.put("startrow", Integer.toString(page));
		map.put("endrow", Integer.toString(limit));
		List<ReviewVO> list = ss.selectList("review_searchTitle", map);
		return list;
	}

	public static List<ReviewVO> searchContent(String content, int page, int limit) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("content", content);
		map.put("startrow", Integer.toString(page));
		map.put("endrow", Integer.toString(limit));
		List<ReviewVO> list = ss.selectList("review_searchContent", map);
		return list;
	}

	public static List<ReviewVO> searchTitleContent(String search, int page, int limit) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", search);
		map.put("content", search);
		map.put("startrow", Integer.toString(page));
		map.put("endrow", Integer.toString(limit));
		List<ReviewVO> list = ss.selectList("review_searchTitleContent", map);
		return list;
	}
	
	public static List<ReviewVO> searchNick(String search, int page, int limit) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("nick", search);
		map.put("startrow", Integer.toString(page));
		map.put("endrow", Integer.toString(limit));
		List<ReviewVO> list = ss.selectList("review_searchNick", map);
		return list;
	}

	public static List<CommentVO> getCommentList(int boardNo) {
		System.out.println("댓글 리스트 액션 전");
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(boardNo));
		List<CommentVO> list = ss.selectList("review_comment", map);
		System.out.println("댓글 리스트 액션 후");
		return list;
	}

	public static void setReadCountUpdate(int num) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(num));
		ss.update("review_readcount", map);
		ss.commit();
	}

	public static boolean reviewModify(ReviewVO rvo) {
		System.out.println("gasdgsag");
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", rvo.getRw_title());
		map.put("content", rvo.getRw_content());
		if (rvo.getRw_file() == null) {
			map.put("file", "");
		} else {
			map.put("file", rvo.getRw_file());
		}
		map.put("num", Integer.toString(rvo.getRw_num()));
		System.out.println(
				rvo.getRw_title() + " " + rvo.getRw_content() + " " + rvo.getRw_file() + " " + rvo.getRw_num());
		System.out.println("a");
		int x = ss.update("review_modify", map);
		System.out.println("b");

		ss.commit();
		if (x == 0) {
			System.out.println("false");
			return false;
		} else {
			System.out.println("true");
			return true;

		}
	}

	public static ReviewVO getDetail(int num) {
		SqlSession ss = sqlSessionFactory.openSession();
		ReviewVO rvo = null;
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(num));
		rvo = ss.selectOne("review_detail", map);
		return rvo;
	}

	public static boolean reviewInsert(ReviewVO review) {

		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", review.getRw_title());
		map.put("content", review.getRw_content());
		if (review.getRw_file() == null) {
			map.put("file", "");
		} else {
			map.put("file", review.getRw_file());
		}
		map.put("memberno", Integer.toString(review.getM_num()));
		int x = ss.insert("review_insert", map);
		ss.commit();
		if (x == 0) {
			return false;
		}
		return true;
	}

	public static boolean addComment(CommentVO comment) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(comment.getM_num()));
		map.put("content", comment.getCo_content());
		map.put("rwnum", Integer.toString(comment.getRw_num()));
		System.out.println(Integer.toString(comment.getM_num()) + " " + comment.getCo_content() + " "
				+ Integer.toString(comment.getRw_num()));
		int x = ss.insert("comment_insert", map);
		System.out.println(x);
		ss.commit();
		if (x == 0) {
			return false;
		}
		return true;
	}

	public static boolean boardDelete(int num) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(num));
		int x = ss.delete("review_delete", map);
		ss.commit();
		if (x == 0) {
			return false;
		}
		return true;
	}

	public static boolean commentDelete(int num) {
		SqlSession ss = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("num", Integer.toString(num));
		int x = ss.delete("comment_delete", map);
		ss.commit();
		if (x == 0) {
			return false;
		}
		return true;
	}

}
