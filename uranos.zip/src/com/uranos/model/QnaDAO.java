package com.uranos.model;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class QnaDAO {

private static SqlSessionFactory sqlSessionFactory;

	static {
		try {
			Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException("SqlSessionFactory instance. " + e, e);
		}
	}
	
	private static QnaDAO dao = new QnaDAO();
	
	public static QnaDAO getInstance() {
		return dao;
	}

	public static boolean setQnaInsert(QnaVO qna) {
		SqlSession session = sqlSessionFactory.openSession();
		int cnt=session.insert("qna_insert",qna);
		session.commit(); 
		session.close();
		return(cnt > 0)? true : false;
	}
	
	public static boolean setQnaModify(QnaVO qna) {
	
		SqlSession session = sqlSessionFactory.openSession();
		
		session.update("modify", qna);
		
		session.commit();
		session.close();
		return true;
		
	}
	
	public static QnaVO getDetail(QnaVO num) {
		SqlSession session = sqlSessionFactory.openSession();
		QnaVO qnavo = (QnaVO) session.selectOne("detail", num);
		session.commit();
		return qnavo;
	}
	
	public static int setReadCount(QnaVO count) {
		SqlSession session = sqlSessionFactory.openSession();
		int cnt = session.update("readCount", count);
		session.commit();
		session.close();
		return cnt;
	}
	
	public static boolean setQnaDelete(int num) {
		SqlSession session = sqlSessionFactory.openSession();
		session.delete("qna_delete", num);
		session.commit();
		session.close();
		return true;

	}
	
	public static int getMaxNum() {
		SqlSession session = sqlSessionFactory.openSession();
		int result = 0;
		try {
			result = (Integer) session.selectOne("getMaxNum");
		} catch (Exception e) {}
		session.close();
		return result;
	}
	
	public static int getListCount() {
		SqlSession session = sqlSessionFactory.openSession();
		int count = (Integer) session.selectOne("listCount");
        session.close();
		return count;
	}
	

	public static List<QnaVO> getQnaList(int page, int limit) {
		SqlSession session = sqlSessionFactory.openSession();
		HashMap<String, String> map = new HashMap<String, String>();
		int startrow = (page - 1) * 10 + 1;
		int endrow = startrow + limit - 1;
		
		map.put("startrow",Integer.toString(startrow));
		map.put("endrow", Integer.toString(endrow));
		List<QnaVO> list = session.selectList("qnaList",map);
        session.close();
		return list;
		
	}
	
	  public static int qnaReply(QnaVO board){
			SqlSession session = sqlSessionFactory.openSession();
	        int result = session.insert("qnaReply", board);
	        session.commit();
	        session.close();
			return result;
	    }
	  
	  public static void replyUpReply(QnaVO board){
			SqlSession session = sqlSessionFactory.openSession();
	        session.update("qnaupReply",board);
	        session.commit();
	        session.close();
	    }
	  
		public static QnaVO getDetailReply(int num) {
			SqlSession session = sqlSessionFactory.openSession();
			QnaVO qnavo = (QnaVO) session.selectOne("reply", num);
			session.commit();
			session.close();
			return qnavo;
		}
	  

	  
}
