// 닉네임 중복 검사
function nick_dup_check() {
	var nick = $("#txt_nick").val();
	if (nick == "") {
		$("#msg_nick").html("닉네임 항목이 비어있습니다 :(").attr("class", "alert alert-warning");
		$("#txt_nick").focus();
		$("#check_nick").val("false");
		
	} else if (!document.getElementById('txt_nick').checkValidity()) {
		$("#msg_nick").html("제시한 닉네임 형식을 지켜주세요 :(").attr("class", "alert alert-warning");
		$("#txt_nick").focus();
		$("#check_nick").attr("value", "");
		
	} else if (isNick()) {
		$("#msg_nick").html(nick + "을(를) 그대로 사용합니다 :)").attr("class", "alert alert-success");
		$("#check_nick").val(nick);
		
	} else {
		var sendData = "nick=" + nick;
		var isCheck = "";
		$.post("./member/ajax/check_nick.jsp", sendData, function(msg) { // sendData: request
			isCheck = msg; // msg: response
			isCheck = isCheck.trim();

			if (isCheck == "true") {
				$("#msg_nick").html(nick + "은(는) 사용 가능한 닉네임입니다 :)").attr("class", "alert alert-success");
				$("#check_nick").val(nick);
			} else if (isCheck == "false") {
				$("#msg_nick").html(nick + "은(는) 이미 사용 중인 닉네임입니다 :(").attr("class", "alert alert-danger");
				$("#txt_nick").focus();
				$("#check_nick").val("");
			}
		});
	}
}

//닉네임 체크
function nick_word_check() {
	$("#check_nick").val("");
	$("#msg_nick").empty().removeClass();
}

//비밀번호 검사
function pw_check() {
	var pw = $("#txt_pw").val();
	var pw_cf = $("#txt_pw_confirm").val();

	if (pw == "" || pw_cf == "") {
		$("#msg_pw").empty().removeClass();
	} else if (pw != pw_cf) {
		$("#msg_pw").html("비밀번호가 같지 않습니다 :(").attr("class","alert alert-danger");
	} else {
		$("#msg_pw").html("비밀번호가 일치합니다 :)").attr("class", "alert alert-success");
	}
}

// 주소 리셋
function addr_reset() {
	$("#postcode").val("");
	$("#address").val("");
	$("#address2").val("");
	$("#postcode").focus();
}

// 회원 정보 수정
function adjust() {
	
	if (!document.getElementById('txt_pw').checkValidity()) { // 비밀번호 검사
	} else if ($("#check_nick").val() == "") { // 닉네임 검사
		if (!isNick()) {
			nick_dup_check();			
		}
	}
	
	$("#btn_adjust_start").click();
	
}

// 엔터키 치면 바로 submit 하지 않고 유효성 검사 메소드 거치고 submit 함.
function enterkey_submit() {
	var key = event.keyCode;
	
	if (key == 13) {
		adjust();
	}
}

// 시작 시
$(function() {
	
	// 체크박스 바뀔 때
	$("#chk_pw").change(function() {
		if ($("#chk_pw").is(":checked")) { // 비밀번호 변경 안할 때
			$("#txt_pw").attr("readonly", "readonly");
			$("#form_pw_confirm").css("display", "none");
			$("#form_pw_confirm").removeAttr("required")
			
		} else { // 비밀번호 변경 할 때
			$("#txt_pw").removeAttr("readonly");
			$("#form_pw_confirm").css("display", "block");
			$("#form_pw_confirm").attr("required", "required");
		}
	});
	
});