// 아이디 중복 검사
function id_dup_check() {
	var id = $("#txt_id").val();
	if (id == "") {
		$("#msg_id").html("아이디 항목이 비어있습니다 :(").attr("class", "alert alert-warning");
		$("#txt_id").focus();
		$("#check_id").attr("value", "");

	} else if (!document.getElementById('txt_id').checkValidity()) {
		$("#msg_id").html("제시한 아이디 형식을 지켜주세요 :(").attr("class", "alert alert-warning");
		$("#txt_id").focus();
		$("#check_id").attr("value", "");
		
	} else {
		var sendData = "id=" + id;
		var isCheck = "";
		$.post("./member/ajax/check_id.jsp", sendData, function(msg) { // sendData: request
			isCheck = msg; // msg: response
			isCheck = isCheck.trim();
			
			if (isCheck == "true") {
				$("#msg_id").html(id + "은(는) 사용 가능한 아이디입니다 :)").attr("class", "alert alert-success");
				$("#check_id").val("true");

			} else if (isCheck == "false") {
				$("#msg_id").html(id + "은(는) 이미 사용 중인 아이디입니다 :(").attr("class", "alert alert-danger");
				$("#txt_id").focus();
				$("#check_id").val("");
			}
		});
	}
}

// 닉네임 중복 검사
function nick_dup_check() {
	var nick = $("#txt_nick").val();
	if (nick == "") {
		$("#msg_nick").html("닉네임 항목이 비어있습니다 :(").attr("class", "alert alert-warning");
		$("#txt_nick").focus();
		$("#check_nick").val("false");
		
	} else if (!document.getElementById('txt_nick').checkValidity()) {
		$("#msg_nick").html("제시한 닉네임 형식을 지켜주세요 :(").attr("class", "alert alert-warning");
		$("#txt_nick").focus();
		$("#check_nick").attr("value", "");
		
	} else {
		var sendData = "nick=" + nick;
		var isCheck = "";
		$.post("./member/ajax/check_nick.jsp", sendData, function(msg) { // sendData: request
			isCheck = msg; // msg: response
			isCheck = isCheck.trim();

			if (isCheck == "true") {
				$("#msg_nick").html(nick + "은(는) 사용 가능한 닉네임입니다 :)").attr("class", "alert alert-success");
				$("#check_nick").val(nick);
			} else if (isCheck == "false") {
				$("#msg_nick").html(nick + "은(는) 이미 사용 중인 닉네임입니다 :(").attr("class", "alert alert-danger");
				$("#txt_nick").focus();
				$("#check_nick").val("");
			}
		});
	}
}

//아이디 체크
function id_word_check() {
	$("#check_id").val("");
	$("#msg_id").empty().removeClass();
}

//닉네임 체크
function nick_word_check() {
	$("#check_nick").val("");
	$("#msg_nick").empty().removeClass();
}

// 비밀번호 검사
function pw_check() {
	var pw = $("#txt_pw").val();
	var pw_cf = $("#txt_pw_confirm").val();

	if (pw == "" || pw_cf == "") {
		$("#msg_pw").empty().removeClass();
	} else if (pw != pw_cf) {
		$("#msg_pw").html("비밀번호가 같지 않습니다 :(").attr("class","alert alert-danger");
	} else {
		$("#msg_pw").html("비밀번호가 일치합니다 :)").attr("class", "alert alert-success");
	}
}

// 주소 리셋
function addr_reset() {
	$("#postcode").val("");
	$("#address").val("");
	$("#address2").val("");
	$("#postcode").focus();
}

// 회원가입
function signup() {
	
	if ($("#check_id").val() == "") { // 아이디 검사
		id_dup_check();
		
	} else if (!document.getElementById('txt_pw').checkValidity() || 
			!document.getElementById('txt_pw_confirm').checkValidity()) { // 비밀번호 검사
		
	} else if ($("#txt_pw").val() != $("#txt_pw_confirm").val()) { // 비밀번호 일치 검사
		alert("비밀번호가 일치하지 않습니다. 비밀번호를 확인 해주세요!");
		
	} else if ($("#check_nick").val() == "") { // 닉네임 검사
		nick_dup_check();
		
	}
	
	$("#btn_signup_start").click();
}

// 엔터키 치면 바로 submit 하지 않고 유효성 검사 메소드 거치고 submit 함.
function enterkey_submit() {
	var key = event.keyCode;
	
	if (key == 13) {
		signup();
	}
}
